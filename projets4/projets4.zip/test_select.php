<?php

   


   if($_POST['password']) 
		echo $_POST['password'], "<BR>";
   else echo" password is not correct", "<BR>";
   $password = $_POST['password'];

  $host        = "host=212.237.28.119";
  $port        = "port=5432";
  $dbname      = "dbname=limedb";
  $credentials = "user=limedbadministrator password=1Cisco2";

  $db = pg_connect( "$host $port $dbname $credentials"  );
  if(!$db){
     echo "Error : Unable to open database\n";
  } else {
     echo "Opened database successfully\n";
  }

   $surveyID_in_bdd = "select surveyls_survey_id from surveys_languagesettings";

   $result_surveyID = pg_query($db,$surveyID_in_bdd);
	while ($r1 = pg_fetch_row($result_surveyID)){
      		print $r1[0] ."<br>";

			$db_table = "tokens_".$r1[0];
			echo  $db_table."<br>";

				$password_in_bdd = "select token from $db_table where  token = '$password'";
				$result_password = pg_query($db,$password_in_bdd);
				while ($r2 = pg_fetch_row($result_password)){
				print  $r2[0] ."<br>";
				echo "https://s4proj15.ddns.net/index.php/".$r1[0]."?lang=en"."<br>";
				}			
  		 }


?>  