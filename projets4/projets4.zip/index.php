<!DOCTYPE html>
<html lang="fr">
<head><link href= "fic_style.css"
      rel="stylesheet">
    <meta charset="utf-8"/>
    <title> 
          Page d'acceuil de limesurvey</title>
    </title>
</head>
<body bgcolor="#00FFFF"> 

  <h1> Welcome to our application </h1> 
<div align="center">
<h3> please login in</h3>
		<form method="post" name="patronyme" action="test_select.php">

		password <input type="text" name="password" size="20"/> <br/>

		<input type="submit" name="post" value=login in>
		</form>

</div>


  </body>
</html>
